# 2023 Skickar for Retia
#
# SPDX-License-Identifier: MIT

import audiocore
import board
import audiobusio
import neopixel
import touchio
import time
import random

# Constants
MIN_PLAYBACK_TIME = 4.2  # Minimum playback time in seconds. Change this value as needed.

# Initialize a strip of 11 NeoPixels on IO12
strip = neopixel.NeoPixel(board.IO12, 11)

# Initialize capacitive touch on IO14
touch = touchio.TouchIn(board.IO14)

# For ESP32-S2 mini module
audio = audiobusio.I2SOut(board.IO3, board.IO8, board.IO40)

last_play_time = 0  # Timestamp to track when the audio started playing

while True:
    # The following line prints the capacitive touch value to serial.
    # Commented out to make the code work even if serial isn't available.
    # print("Capacitive value:", touch.raw_value)

    time.sleep(0.1)  # Add a small delay

    current_time = time.monotonic()

    if touch.raw_value > 32000 and not audio.playing:  # Start playing if capacitive touch value is over 25000 and audio is not playing
        # Randomly pick between the five audio files
        chosen_file = random.choice(["term0.wav", "term1.wav", "term2.wav", "term3.wav", "term4.wav", "term5.wav"])
        wave_file = open(chosen_file, "rb")
        wave = audiocore.WaveFile(wave_file)

        audio.play(wave)
        last_play_time = current_time  # Update the timestamp
        strip.fill((255, 0, 0))  # Set the entire strip to red

    # Check if capacitive touch value drops below 30000, audio is playing, and it's been at least MIN_PLAYBACK_TIME seconds since the audio started playing
    elif touch.raw_value < 30000 and audio.playing and (current_time - last_play_time) > MIN_PLAYBACK_TIME:
        audio.stop()  # Stop the audio
        strip.fill((0, 255, 0))  # Set the entire strip to green
    elif touch.raw_value > 25000 and audio.playing:  # If capacitive touch value is still above 25000, keep playing
        continue
    else:
        strip.fill((0, 255, 0))  # Set the entire strip to green when there isn't a touch detected
